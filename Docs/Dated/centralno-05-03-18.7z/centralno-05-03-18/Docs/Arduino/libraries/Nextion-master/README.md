# Nextion
A Modified Nextion Library for ESP8266 with Software Serial support added
- No more Nextion disconnection for software upload to ESP8266
- No more conflicts with Serial debug
- Change Software Serial pins in line 18 of NexHardware.cpp

For more information visit <a href="https://hobbytronics.com.pk/noobs-guide-to-nextion-displays/">NOOB’S GUIDE TO NEXTION DISPLAYS WITH ESP8266 | NODEMCU | WEMOS D1 MINI</a>
